package com.github.wdx.spirngstreamactivemqbinder.activemq.mapper;

public class StreamActivemqHeaderProperty {

	public static final String PARTITION_PEOPERTY = "centalinePartitionProperty";
}
