package com.github.wdx.spirngstreamactivemqbinder.activemq.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.stream.binder.AbstractExtendedBindingProperties;
import org.springframework.cloud.stream.binder.BinderSpecificPropertiesProvider;

@ConfigurationProperties("spring.cloud.stream.activemq")
public class ActiveMQExtendedBindingProperties extends AbstractExtendedBindingProperties<
		ActiveMQConsumerProperties, ActiveMQProducerProperties,ActiveMQBindingProperties> {
	private static final String DEFAULTS_PREFIX = "spring.cloud.stream.activemq.default";
	@Override
	public String getDefaultsPrefix() {
		return DEFAULTS_PREFIX;
	}

	@Override
	public Class<? extends BinderSpecificPropertiesProvider> getExtendedPropertiesEntryClass() {
		return ActiveMQBindingProperties.class;
	}
}
